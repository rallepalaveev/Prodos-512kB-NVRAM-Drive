NVRAM DRIVE for Apple II, (c)1995-2023 by Ralle Palaveev

This is a ProDOS formatted hard drive with 512kB capacity.

This version is for the 512kB NVRAM DRIVE hardware version 2.3 and above.

Full r/w capability with dedicated RAM onboard for writing.

Use hardware and/or software at your own risk. No warranty taken.
No responsibility taken for any untoward effects or damage to hardware of any kind.

The 512kB .PO file is the full firmware
The 140kB files contain the tools to be used with the card while in the Apple II
The 1MB .hdv file contains all data for a full restore with the card while in the Apple II

V43

The tools can format, back-up and restore the NVRAM DRIVE

The disks has a full image of the current version and programs

Instructions to use the tools:

1. Install NVRAM DRIVE in one slot
2. Mount the disk with "Program" in the name in an emulator or floppy
3. Boot from the image and follow the instructions

Change log:

V43 - 03 Jun 2023, Code optimization
V42 - 27 feb 2023, Removed C006 and C00B functionality as redundant
V41 - 15 feb 2023, Optimized code
V40 - 10 Feb 2023, Code changed to accommodate removal of 74133
V39 - 05 Feb 2023, Code optimization
V38 - 31 Jan 2023, New software version compatible only with hardware version 2.3 and above - not compatible with lower hardware versions
V36 - 16 Oct 2022, Interrupt disable added to subroutine for writing
V35 - 02 Oct 2022, Optimization of code
V34 - 14 Apr 2022, Fixed incompatibility with 64kB systems and some games (PoP)
V33 - 30 Mar 2022, Changed buffer to addresses $6000-$7100, $BF98 zeroed at startup
V30 - 20 Mar 2022, All ZP addresses are resotred after use
V29 - 19 Mar 2022, Fixed incompatibility when copying with Copy+
V28 - 05 Jan 2022, Initial official version
